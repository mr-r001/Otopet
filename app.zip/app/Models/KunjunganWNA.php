<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KunjunganWNA extends Model
{
    protected $fillable = ['name'];
}
