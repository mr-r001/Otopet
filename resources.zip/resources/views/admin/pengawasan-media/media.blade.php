@if($media <> NULL) 
    {{ $media['nama'] }}
@endif
