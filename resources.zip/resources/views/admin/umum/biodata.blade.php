@if($biodata <> NULL) 
    {{ $biodata['nama'] }}
@endif
