@if($kecamatan <> NULL) 
    {{ $kecamatan['name'] }}
@endif