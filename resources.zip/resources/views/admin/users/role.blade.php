@if($role <> NULL) 
    {{ $role['name'] }}
@endif