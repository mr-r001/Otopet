@if($isCompleted == 0)
    <span class="badge badge-pill badge-danger">InCompleted</span>
@else
    <span class="badge badge-pill badge-success">Completed</span>
@endif