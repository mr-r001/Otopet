@if($organisasi <> NULL)
    {{ $organisasi['nama'] }}
@endif