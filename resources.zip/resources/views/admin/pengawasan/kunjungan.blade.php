@if($kunjungan <> NULL) 
    {{ $kunjungan['name'] }}
@endif
