@if($barang <> NULL) 
    {{ $barang['nama'] }}
@endif
