<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; Kejari Pagar Alam
    </div>
</footer>
